# Keep Android framework callbacks and alarm data types.
-keepclassmembers class com.example.alarmclock.AlarmReceiver { *; }
-keepclassmembers class com.example.alarmclock.AlarmActivity { *; }
