package com.example.alarmclock;

import android.media.AudioAttributes;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Locale;

public class AlarmActivity extends AppCompatActivity {
    private Ringtone ringtone;
    private Vibrator vibrator;
    private Alarm alarm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        long id = getIntent().getLongExtra("alarm_id", -1);
        for (Alarm item : new AlarmStore(this).load()) {
            if (item.id == id) alarm = item;
        }

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setGravity(android.view.Gravity.CENTER);
        layout.setBackgroundColor(0xFF121212);
        int pad = (int) (24 * getResources().getDisplayMetrics().density);
        layout.setPadding(pad, pad, pad, pad);

        TextView time = new TextView(this);
        time.setText(alarm == null ? "--:--" : alarm.timeText());
        time.setTextSize(64);
        time.setTextColor(0xFFFFFFFF);
        time.setGravity(android.view.Gravity.CENTER);

        TextView title = new TextView(this);
        title.setText(getString(R.string.app_name));
        title.setTextSize(18);
        title.setTextColor(0xFFBBBBBB);
        title.setGravity(android.view.Gravity.CENTER);

        Button snooze = new Button(this);
        snooze.setText(getString(R.string.snooze));
        snooze.setAllCaps(false);
        snooze.setOnClickListener(v -> {
            if (alarm != null) AlarmScheduler.snooze(this, alarm);
            stopAlarm();
            finish();
        });

        Button dismiss = new Button(this);
        dismiss.setText(getString(R.string.dismiss));
        dismiss.setAllCaps(false);
        dismiss.setOnClickListener(v -> {
            stopAlarm();
            finish();
        });

        layout.addView(title);
        layout.addView(time);
        layout.addView(snooze);
        layout.addView(dismiss);
        setContentView(layout);
        startAlarm();
    }

    private void startAlarm() {
        Uri uri = alarm != null && alarm.ringtoneUri != null
                ? Uri.parse(alarm.ringtoneUri)
                : RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
        ringtone = RingtoneManager.getRingtone(this, uri);
        if (ringtone != null) {
            ringtone.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build());
            ringtone.play();
        }
        if (alarm != null && alarm.vibrate) {
            vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);
            if (vibrator != null) vibrator.vibrate(
                    VibrationEffect.createWaveform(new long[]{0, 800, 500}, 0));
        }
    }

    private void stopAlarm() {
        if (ringtone != null) ringtone.stop();
        if (vibrator != null) vibrator.cancel();
    }

    @Override
    protected void onDestroy() {
        stopAlarm();
        super.onDestroy();
    }
}
