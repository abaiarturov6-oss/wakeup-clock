package com.example.alarmclock;

import android.Manifest;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class MainActivity extends AppCompatActivity {
    private static final int RINGTONE_REQUEST = 1001;
    private AlarmStore store;
    private List<Alarm> alarms;
    private AlarmAdapter adapter;
    private Alarm ringtoneTarget;
    private RecyclerView recycler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        store = new AlarmStore(this);
        alarms = store.load();

        recycler = findViewById(R.id.recycler);
        recycler.setLayoutManager(new LinearLayoutManager(this));
        adapter = new AlarmAdapter(alarms, new AlarmAdapter.Callbacks() {
            @Override
            public void onToggle(Alarm alarm) {
                store.save(alarms);
                AlarmScheduler.schedule(MainActivity.this, alarm);
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onEdit(Alarm alarm) {
                showAlarmDialog(alarm);
            }
        });
        recycler.setAdapter(adapter);

        ImageButton add = findViewById(R.id.fab_add);
        add.setOnClickListener(v -> {
            java.util.Calendar now = java.util.Calendar.getInstance();
            Alarm alarm = new Alarm(System.currentTimeMillis(), now.get(java.util.Calendar.HOUR_OF_DAY),
                    now.get(java.util.Calendar.MINUTE));
            alarm.ringtoneUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM).toString();
            showAlarmDialog(alarm);
        });

        requestPermissions();
    }

    private void requestPermissions() {
        if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }
        if (Build.VERSION.SDK_INT >= 31) {
            android.app.AlarmManager manager =
                    (android.app.AlarmManager) getSystemService(ALARM_SERVICE);
            if (!manager.canScheduleExactAlarms()) {
                startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM));
            }
        }
    }

    private void showAlarmDialog(Alarm alarm) {
        boolean isNew = !alarms.contains(alarm);
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(20);
        root.setPadding(pad, pad, pad, pad);

        TextView time = new TextView(this);
        time.setText(alarm.timeText());
        time.setTextSize(44);
        time.setGravity(Gravity.CENTER);
        time.setOnClickListener(v -> new TimePickerDialog(this, (picker, hour, minute) -> {
            alarm.hour = hour;
            alarm.minute = minute;
            time.setText(alarm.timeText());
        }, alarm.hour, alarm.minute, true).show());

        Switch vibration = new Switch(this);
        vibration.setText(getString(R.string.vibration));
        vibration.setChecked(alarm.vibrate);

        LinearLayout repeatDays = new LinearLayout(this);
        repeatDays.setOrientation(LinearLayout.VERTICAL);
        repeatDays.addView(makeSectionTitle(getString(R.string.repeat)));
        String[] names = {"Воскресенье", "Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота"};
        CheckBox[] checks = new CheckBox[7];
        for (int i = 0; i < 7; i++) {
            final int day = i;
            checks[i] = new CheckBox(this);
            checks[i].setText(names[i]);
            checks[i].setChecked(alarm.repeat[i]);
            repeatDays.addView(checks[i]);
        }

        Button ringtone = new Button(this);
        ringtone.setText(getString(R.string.ringtone));
        ringtone.setAllCaps(false);
        ringtone.setOnClickListener(v -> {
            ringtoneTarget = alarm;
            Intent intent = new Intent(RingtoneManager.ACTION_RINGTONE_PICKER);
            intent.putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALARM);
            intent.putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true);
            intent.putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, true);
            if (alarm.ringtoneUri != null) {
                intent.putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, Uri.parse(alarm.ringtoneUri));
            }
            startActivityForResult(intent, RINGTONE_REQUEST);
        });

        root.addView(time);
        root.addView(vibration);
        root.addView(ringtone);
        root.addView(repeatDays);
        scroll.addView(root);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(isNew ? getString(R.string.add_alarm) : "Редактировать будильник")
                .setView(scroll)
                .setPositiveButton(R.string.save, null)
                .setNegativeButton(R.string.delete, (d, w) -> {
                    if (!isNew) {
                        AlarmScheduler.cancel(this, alarm.id);
                        alarms.remove(alarm);
                        store.save(alarms);
                        adapter.notifyDataSetChanged();
                    }
                })
                .create();
        dialog.show();
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            alarm.vibrate = vibration.isChecked();
            for (int i = 0; i < 7; i++) alarm.repeat[i] = checks[i].isChecked();
            if (isNew) alarms.add(alarm);
            alarm.enabled = true;
            store.save(alarms);
            AlarmScheduler.schedule(this, alarm);
            adapter.notifyDataSetChanged();
            dialog.dismiss();
        });
    }

    private TextView makeSectionTitle(String text) {
        TextView title = new TextView(this);
        title.setText(text);
        title.setTextSize(16);
        title.setPadding(0, dp(12), 0, dp(6));
        return title;
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == RINGTONE_REQUEST && data != null && ringtoneTarget != null) {
            Uri uri = data.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI);
            ringtoneTarget.ringtoneUri = uri == null ? null : uri.toString();
        }
    }
}
