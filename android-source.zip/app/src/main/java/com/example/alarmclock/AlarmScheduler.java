package com.example.alarmclock;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;

import java.util.Calendar;

public class AlarmScheduler {
    public static void schedule(Context context, Alarm alarm) {
        cancel(context, alarm.id);
        if (!alarm.enabled) return;

        Calendar next = nextTime(alarm);
        Intent intent = new Intent(context, AlarmReceiver.class);
        intent.putExtra("alarm_id", alarm.id);
        PendingIntent pending = PendingIntent.getBroadcast(
                context, (int) alarm.id, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        try {
            manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next.getTimeInMillis(), pending);
        } catch (SecurityException ignored) {
            manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next.getTimeInMillis(), pending);
        }
    }

    public static void cancel(Context context, long id) {
        Intent intent = new Intent(context, AlarmReceiver.class);
        PendingIntent pending = PendingIntent.getBroadcast(
                context, (int) id, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        manager.cancel(pending);
    }

    public static Calendar nextTime(Alarm alarm) {
        Calendar now = Calendar.getInstance();
        Calendar candidate = Calendar.getInstance();
        candidate.set(Calendar.HOUR_OF_DAY, alarm.hour);
        candidate.set(Calendar.MINUTE, alarm.minute);
        candidate.set(Calendar.SECOND, 0);
        candidate.set(Calendar.MILLISECOND, 0);

        if (alarm.hasRepeat()) {
            for (int i = 0; i < 8; i++) {
                if (candidate.after(now)) {
                    int dayOfWeek = candidate.get(Calendar.DAY_OF_WEEK) - 1;
                    if (alarm.repeat[dayOfWeek]) return candidate;
                }
                candidate.add(Calendar.DAY_OF_YEAR, 1);
            }
        } else if (candidate.after(now)) {
            return candidate;
        } else {
            candidate.add(Calendar.DAY_OF_YEAR, 1);
        }
        return candidate;
    }

    public static void snooze(Context context, Alarm alarm) {
        Intent intent = new Intent(context, AlarmReceiver.class);
        intent.putExtra("alarm_id", alarm.id);
        PendingIntent pending = PendingIntent.getBroadcast(
                context, (int) alarm.id, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        Calendar time = Calendar.getInstance();
        time.add(Calendar.MINUTE, 10);
        manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, time.getTimeInMillis(), pending);
    }
}
