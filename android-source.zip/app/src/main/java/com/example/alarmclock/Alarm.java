package com.example.alarmclock;

public class Alarm {
    public long id;
    public int hour;
    public int minute;
    public boolean[] repeat = new boolean[7];
    public boolean enabled = true;
    public boolean vibrate = true;
    public String ringtoneUri;

    public Alarm(long id, int hour, int minute) {
        this.id = id;
        this.hour = hour;
        this.minute = minute;
    }

    public String timeText() {
        return String.format(java.util.Locale.getDefault(), "%02d:%02d", hour, minute);
    }

    public String repeatText() {
        String[] names = {"Вс", "Пн", "Вт", "Ср", "Чт", "Пт", "Сб"};
        if (!hasRepeat()) return "Только один раз";
        if (allDays()) return "Каждый день";
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < 7; i++) {
            if (repeat[i]) {
                if (result.length() > 0) result.append(", ");
                result.append(names[i]);
            }
        }
        return result.toString();
    }

    public boolean hasRepeat() {
        for (boolean day : repeat) if (day) return true;
        return false;
    }

    public boolean allDays() {
        for (boolean day : repeat) if (!day) return false;
        return true;
    }
}
