package com.example.alarmclock;

import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class AlarmAdapter extends RecyclerView.Adapter<AlarmAdapter.Holder> {
    interface Callbacks {
        void onToggle(Alarm alarm);
        void onEdit(Alarm alarm);
    }

    private final List<Alarm> alarms;
    private final Callbacks callbacks;

    AlarmAdapter(List<Alarm> alarms, Callbacks callbacks) {
        this.alarms = alarms;
        this.callbacks = callbacks;
    }

    @NonNull
    @Override
    public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LinearLayout row = new LinearLayout(parent.getContext());
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(parent, 16), dp(parent, 14), dp(parent, 16), dp(parent, 14));
        row.setBackgroundColor(0xFF1E1E1E);
        row.setLayoutParams(new RecyclerView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        row.setMinimumHeight(dp(parent, 92));

        LinearLayout text = new LinearLayout(parent.getContext());
        text.setOrientation(LinearLayout.VERTICAL);
        text.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));

        TextView time = new TextView(parent.getContext());
        time.setTextColor(0xFFFFFFFF);
        time.setTextSize(34);
        time.setTypeface(Typeface.DEFAULT);
        text.addView(time);

        TextView repeat = new TextView(parent.getContext());
        repeat.setTextColor(0xFFAAAAAA);
        repeat.setTextSize(13);
        text.addView(repeat);

        Switch enabled = new Switch(parent.getContext());
        enabled.setChecked(true);
        row.addView(text);
        row.addView(enabled);

        Holder holder = new Holder(row);
        holder.time = time;
        holder.repeat = repeat;
        holder.enabled = enabled;
        return holder;
    }

    private int dp(View parent, int value) {
        return (int) (value * parent.getResources().getDisplayMetrics().density);
    }

    @Override
    public void onBindViewHolder(@NonNull Holder holder, int position) {
        Alarm alarm = alarms.get(position);
        holder.time.setText(alarm.timeText());
        holder.repeat.setText(alarm.repeatText());
        holder.enabled.setOnCheckedChangeListener(null);
        holder.enabled.setChecked(alarm.enabled);
        holder.enabled.setOnCheckedChangeListener((button, checked) -> {
            alarm.enabled = checked;
            callbacks.onToggle(alarm);
        });
        holder.itemView.setOnClickListener(v -> callbacks.onEdit(alarm));
    }

    @Override
    public int getItemCount() {
        return alarms.size();
    }

    static class Holder extends RecyclerView.ViewHolder {
        TextView time;
        TextView repeat;
        Switch enabled;
        Holder(@NonNull View itemView) {
            super(itemView);
        }
    }
}
