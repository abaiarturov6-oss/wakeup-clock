package com.example.alarmclock;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import java.util.List;

public class AlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        long id = intent.getLongExtra("alarm_id", -1);
        Alarm alarm = null;
        if (id >= 0) {
            for (Alarm item : new AlarmStore(context).load()) {
                if (item.id == id) {
                    alarm = item;
                    break;
                }
            }
        }
        if (alarm == null) return;

        Intent activity = new Intent(context, AlarmActivity.class);
        activity.putExtra("alarm_id", alarm.id);
        activity.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        context.startActivity(activity);
        if (alarm.hasRepeat()) {
            AlarmScheduler.schedule(context, alarm);
        } else {
            alarm.enabled = false;
            AlarmStore store = new AlarmStore(context);
            java.util.List<Alarm> alarms = store.load();
            for (int i = 0; i < alarms.size(); i++) {
                if (alarms.get(i).id == alarm.id) {
                    alarms.set(i, alarm);
                    break;
                }
            }
            store.save(alarms);
        }
    }
}
