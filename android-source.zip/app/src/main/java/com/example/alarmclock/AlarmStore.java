package com.example.alarmclock;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class AlarmStore {
    private static final String PREFS = "alarms";
    private static final String LIST = "list";
    private final Context context;

    public AlarmStore(Context context) {
        this.context = context.getApplicationContext();
    }

    public List<Alarm> load() {
        ArrayList<Alarm> result = new ArrayList<>();
        String json = preferences().getString(LIST, "[]");
        try {
            JSONArray array = new JSONArray(json);
            for (int i = 0; i < array.length(); i++) {
                JSONObject object = array.getJSONObject(i);
                Alarm alarm = new Alarm(object.optLong("id"), object.optInt("hour"), object.optInt("minute"));
                alarm.enabled = object.optBoolean("enabled", true);
                alarm.vibrate = object.optBoolean("vibrate", true);
                alarm.ringtoneUri = object.optString("ringtoneUri", null);
                JSONArray repeat = object.optJSONArray("repeat");
                if (repeat != null) {
                    for (int day = 0; day < 7 && day < repeat.length(); day++) {
                        alarm.repeat[day] = repeat.optBoolean(day);
                    }
                }
                result.add(alarm);
            }
        } catch (Exception ignored) {
        }
        return result;
    }

    public void save(List<Alarm> alarms) {
        JSONArray array = new JSONArray();
        try {
            for (Alarm alarm : alarms) {
                JSONObject object = new JSONObject();
                object.put("id", alarm.id);
                object.put("hour", alarm.hour);
                object.put("minute", alarm.minute);
                object.put("enabled", alarm.enabled);
                object.put("vibrate", alarm.vibrate);
                object.put("ringtoneUri", alarm.ringtoneUri);
                JSONArray repeat = new JSONArray();
                for (boolean day : alarm.repeat) repeat.put(day);
                object.put("repeat", repeat);
                array.put(object);
            }
        } catch (Exception ignored) {
        }
        preferences().edit().putString(LIST, array.toString()).apply();
    }

    private SharedPreferences preferences() {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }
}
